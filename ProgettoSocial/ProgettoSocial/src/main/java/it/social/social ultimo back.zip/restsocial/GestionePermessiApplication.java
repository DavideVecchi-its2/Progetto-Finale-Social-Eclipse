package it.social.restsocial;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

@SpringBootApplication
@EnableJpaAuditing

public class GestionePermessiApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionePermessiApplication.class, args);
	}

}
